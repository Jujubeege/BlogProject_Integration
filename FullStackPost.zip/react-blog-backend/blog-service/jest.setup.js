process.env.JWT_SECRET = "mock-secret";
