# My React Blog

A blog platform built with React and Vite.

## Setup Instructions
1. Run `npm install --legacy-peer-deps` to install dependencies
2. Run `npm test` to run the unit testcases
3. Run `npm run dev` to run the project
